package org.example.projetogamificacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoGamificacaoApplicationTests {

    @Test
    void contextLoads() {
    }

}
