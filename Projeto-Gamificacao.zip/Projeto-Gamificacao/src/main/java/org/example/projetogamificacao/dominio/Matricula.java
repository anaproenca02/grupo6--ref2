package org.example.projetogamificacao.dominio;

import jakarta.persistence.*;

@Entity
@Table(name = "MATRICULAS")
public class Matricula {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double notaFinal;

    @Enumerated(EnumType.STRING)
    private StatusMatricula status;

    @ManyToOne
    private Aluno aluno;

    @ManyToOne
    private Curso curso;

    public Matricula() {
        this.status = StatusMatricula.EM_ANDAMENTO;
    }

    public void concluir(double nota) {
        this.notaFinal = nota;
        this.status = StatusMatricula.CONCLUIDO;
    }
}