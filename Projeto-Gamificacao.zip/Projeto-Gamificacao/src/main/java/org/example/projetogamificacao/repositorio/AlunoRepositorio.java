package org.example.projetogamificacao.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AlunoRepositorio extends JpaRepository<AlunoRepositorio, Long> {
}