package org.example.projetogamificacao.dominio;

import jakarta.persistence.*;

@Entity
@Table(name = "ALUNOS")
public class Aluno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String email;
    private int totalCursosConcluidos;
    private int moedas;

    @Enumerated(EnumType.STRING)
    private PlanoAssinatura plano;

    public Aluno() {
        this.plano = PlanoAssinatura.BASICO;
    }

    public void concluirCurso(double nota) {
        if (nota >= 7.0) {
            totalCursosConcluidos++;
            moedas += 3;
            atualizarPlano();
        }
    }

    public void atualizarPlano() {
        if (totalCursosConcluidos >= 12) {
            plano = PlanoAssinatura.PREMIUM;
        }
    }

    public Long getId() { return id; }
}