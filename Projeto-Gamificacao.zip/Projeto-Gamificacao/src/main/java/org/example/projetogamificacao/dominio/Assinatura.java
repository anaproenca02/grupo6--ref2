package org.example.projetogamificacao.dominio;

import jakarta.persistence.*;

@Entity
@Table(name = "ASSINATURAS")
public class Assinatura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private boolean ativa;

    @Enumerated(EnumType.STRING)
    private PlanoAssinatura tipo;

    @OneToOne
    private Aluno aluno;

    public Assinatura() {
        this.ativa = true;
    }

    public void cancelar() {
        this.ativa = false;
    }
}