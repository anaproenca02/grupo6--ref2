package org.example.projetogamificacao.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AssinaturaRepositorio extends JpaRepository<AssinaturaRepositorio, Long> {
}