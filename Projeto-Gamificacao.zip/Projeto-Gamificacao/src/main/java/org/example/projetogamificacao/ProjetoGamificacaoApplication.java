package org.example.projetogamificacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoGamificacaoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjetoGamificacaoApplication.class, args);
    }

}
    