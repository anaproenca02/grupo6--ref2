package org.example.projetogamificacao.dominio;

public enum PlanoAssinatura {
    BASICO,
    PREMIUM
}