package org.example.projetogamificacao.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MatriculaRepositorio extends JpaRepository<MatriculaRepositorio, Long> {
}