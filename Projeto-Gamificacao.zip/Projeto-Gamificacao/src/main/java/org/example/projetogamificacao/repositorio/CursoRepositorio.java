package org.example.projetogamificacao.repositorio;

import org.example.projetogamificacao.dominio.Curso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CursoRepositorio extends JpaRepository<Curso, Long> {
}
