package org.example.projetogamificacao.dominio;

public enum StatusMatricula {
    EM_ANDAMENTO,
    CONCLUIDO,
    CANCELADO
}